export type Question = {
  type: 'single' | 'multiple' | 'numeric' | 'matching' | 'ordering' | 'text'
  q: string
  topic: string
  points: number
  why: string
  options?: string[]
  correct?: number | number[] | number | string[] | string
  unit?: string
  pairs?: { term: string; choices: string[]; correct: string }[]
  items?: string[]
  expectedKeywords?: string[]
}
export type ExamAnswer = number | string | number[] | string[] | Record<string, string>

export const questions: Question[] = [
  {
    type:'single', topic:'Elektrotechnische Grundlagen', points:1,
    q:'Welche Einheit wird für die elektrische Spannung verwendet?',
    options:['Ampere (A)','Volt (V)','Ohm (Ω)','Watt (W)'], correct:1,
    why:'Die elektrische Spannung wird in Volt (V) angegeben. Ampere ist die Einheit der Stromstärke, Ohm die des Widerstands und Watt die der Leistung.'
  },
  {
    type:'multiple', topic:'Elektrotechnische Grundlagen', points:2,
    q:'Welche Aussagen zur Reihenschaltung treffen zu? Wähle alle richtigen Antworten.',
    options:['Durch alle Bauteile fließt dieselbe Stromstärke.','Die Spannung ist an jedem Bauteil immer gleich.','Die Teilwiderstände addieren sich zum Gesamtwiderstand.','Fällt ein Bauteil aus, wird der Stromkreis normalerweise unterbrochen.'],
    correct:[0,2,3],
    why:'In einer Reihenschaltung ist die Stromstärke überall gleich. Die Widerstände addieren sich. Eine Unterbrechung an einer Stelle unterbricht den gesamten Stromkreis.'
  },
  {
    type:'numeric', topic:'Berechnungen', points:2,
    q:'An einem Widerstand von 6 Ω liegt eine Spannung von 12 V an. Wie groß ist die Stromstärke?',
    correct:2, unit:'A',
    why:'Nach dem ohmschen Gesetz gilt I = U / R. Damit ergibt sich I = 12 V / 6 Ω = 2 A.'
  },
  {
    type:'matching', topic:'Elektrische Größen', points:3,
    q:'Ordne jeder elektrischen Größe die passende Einheit zu.',
    pairs:[
      {term:'Spannung',choices:['Volt (V)','Ampere (A)','Ohm (Ω)','Watt (W)'],correct:'Volt (V)'},
      {term:'Stromstärke',choices:['Volt (V)','Ampere (A)','Ohm (Ω)','Watt (W)'],correct:'Ampere (A)'},
      {term:'Widerstand',choices:['Volt (V)','Ampere (A)','Ohm (Ω)','Watt (W)'],correct:'Ohm (Ω)'}
    ],
    why:'Spannung wird in Volt, Stromstärke in Ampere und Widerstand in Ohm angegeben.'
  },
  {
    type:'ordering', topic:'Arbeitsmethodik', points:2,
    q:'Bringe die Schritte einer strukturierten Berechnung in die richtige Reihenfolge.',
    items:['Formel auswählen','Ergebnis und Einheit prüfen','Gegebene Werte notieren','Werte einsetzen und berechnen','Gesuchte Größe bestimmen'],
    correct:['Gegebene Werte notieren','Gesuchte Größe bestimmen','Formel auswählen','Werte einsetzen und berechnen','Ergebnis und Einheit prüfen'],
    why:'Ein strukturierter Lösungsweg beginnt mit den gegebenen Werten und der gesuchten Größe. Danach folgt die passende Formel, das Einsetzen und abschließend die Plausibilitäts- und Einheitenprüfung.'
  },
  {
    type:'text', topic:'Fachverständnis', points:2,
    q:'Nenne zwei wichtige Eigenschaften einer Reihenschaltung und erkläre sie kurz.',
    expectedKeywords:['stromstaerke','widerstaende'],
    why:'Eine vollständige Antwort sollte unter anderem erwähnen, dass die Stromstärke durch alle Bauteile gleich ist und dass sich die Einzelwiderstände zum Gesamtwiderstand addieren. In einer echten Prüfung wird Freitext fachlich durch eine berechtigte Person bewertet; diese Vorschau nutzt nur einen einfachen Schlüsselwortvergleich.'
  }
]

export function isAnswered(answer: ExamAnswer | undefined): boolean {
  if (answer === undefined || answer === null) return false
  if (typeof answer === 'string') return answer.trim().length > 0
  if (Array.isArray(answer)) return answer.length > 0
  if (typeof answer === 'object') return Object.values(answer).some(value => value.trim().length > 0)
  return true
}

export function isQuestionCorrect(question: Question, answer: ExamAnswer | undefined): boolean {
  if (!isAnswered(answer)) return false
  if (question.type === 'single') return Number(answer) === question.correct
  if (question.type === 'multiple') {
    const actual = Array.isArray(answer) ? [...answer].map(Number).sort() : []
    const expected = Array.isArray(question.correct) ? [...question.correct].map(Number).sort() : []
    return actual.length === expected.length && actual.every((value, index) => value === expected[index])
  }
  if (question.type === 'numeric') return Math.abs(Number(String(answer).replace(',', '.')) - Number(question.correct)) < 0.000001
  if (question.type === 'matching') {
    const values = typeof answer === 'object' && !Array.isArray(answer) ? answer : {}
    return (question.pairs || []).every(pair => values[pair.term] === pair.correct)
  }
  if (question.type === 'ordering') {
    const actual = Array.isArray(answer) ? answer : []
    const expected = Array.isArray(question.correct) ? question.correct : []
    return actual.length === expected.length && actual.every((value, index) => value === expected[index])
  }
  if (question.type === 'text') {
    const text = String(answer).toLocaleLowerCase('de-DE').replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue')
    return (question.expectedKeywords || []).every(keyword => text.includes(keyword))
  }
  return false
}

export function getAnswerText(question: Question, answer: ExamAnswer | undefined): string {
  if (!isAnswered(answer)) return 'Keine Antwort abgegeben'
  if (question.type === 'single') return question.options?.[Number(answer)] || String(answer)
  if (question.type === 'multiple') return (Array.isArray(answer) ? answer : []).map(value => question.options?.[Number(value)]).filter(Boolean).join(' · ')
  if (question.type === 'numeric') return `${answer} ${question.unit || ''}`.trim()
  if (question.type === 'matching') return Object.entries(answer as Record<string, string>).map(([key, value]) => `${key}: ${value}`).join(' · ')
  if (question.type === 'ordering') return (Array.isArray(answer) ? answer : []).join(' → ')
  return String(answer)
}
